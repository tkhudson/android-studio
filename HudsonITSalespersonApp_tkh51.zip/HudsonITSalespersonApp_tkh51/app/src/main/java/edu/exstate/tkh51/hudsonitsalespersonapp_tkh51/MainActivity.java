package edu.exstate.tkh51.hudsonitsalespersonapp_tkh51;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;

public class MainActivity extends ListActivity {

    List<Salesperson> list = new ArrayList<Salesperson>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        Salesperson salesperson1 = new Salesperson();
        salesperson1.setId(101);
        salesperson1.setFname("Tyler");
        salesperson1.setLname("Hudson");
        salesperson1.setPhonenumber("(210)-776-4412");
        salesperson1.setDblgeneratedrevenue(1903.00);
        list.add(salesperson1);

        Salesperson salesperson2 = new Salesperson();
        salesperson2.setId(102);
        salesperson2.setFname("Eric");
        salesperson2.setLname("Johnson");
        salesperson2.setPhonenumber("(512)-685-9380");
        salesperson2.setDblgeneratedrevenue(964.00);
        list.add(salesperson2);

        Salesperson salesperson3 = new Salesperson();
        salesperson3.setId(103);
        salesperson3.setFname("George");
        salesperson3.setLname("Davis");
        salesperson3.setPhonenumber("(512)-665-2945");
        salesperson3.setDblgeneratedrevenue(1490.00);
        list.add(salesperson3);

        Salesperson salesperson4 = new Salesperson();
        salesperson4.setId(104);
        salesperson4.setFname("Carl");
        salesperson4.setLname("Johns");
        salesperson4.setPhonenumber("(512)-281-2294");
        salesperson4.setDblgeneratedrevenue(1300.00);
        list.add(salesperson4);

        Salesperson salesperson5 = new Salesperson();
        salesperson5.setId(105);
        salesperson5.setFname("Kurt");
        salesperson5.setLname("Russel");
        salesperson5.setPhonenumber("(389)-234-9483");
        salesperson5.setDblgeneratedrevenue(789.00);
        list.add(salesperson5);

        setListAdapter(new ArrayAdapter<Salesperson>(MainActivity.this, R.layout.layout_firstscreen, R.id.txtSalesperson,list));
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id){
        Salesperson selectedsalesperson = list.get(position);

        DecimalFormat currency = new DecimalFormat("#,###.##");

        if(selectedsalesperson.getDblgeneratedrevenue() < 1000) {
            Toast.makeText(MainActivity.this, "The revenue does not meet target!" + " Generated revenue: " + currency.format(selectedsalesperson.getDblgeneratedrevenue()),
                    Toast.LENGTH_LONG).show();
        }

        SharedPreferences prefer = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        SharedPreferences.Editor editor = prefer.edit();
        editor.putInt("KeyID", selectedsalesperson.getId());
        editor.putString("KeyFName", selectedsalesperson.getFname());
        editor.putString("KeyLName", selectedsalesperson.getLname());
        editor.putString("KeyPhonenumber", selectedsalesperson.getPhonenumber());
        editor.putFloat("KeyGenRev", (float) selectedsalesperson.getDblgeneratedrevenue());

        editor.commit();

        startActivity(new Intent(MainActivity.this, Secondscreen.class));

    }
}