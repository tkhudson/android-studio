package edu.exstate.tkh51.hudsonitsalespersonapp_tkh51;

import androidx.annotation.NonNull;

public class Salesperson {
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String name) {
        this.fname = name;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String name) {
        this.lname = name;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public double getDblgeneratedrevenue() {
        return dblgeneratedrevenue;
    }

    public void setDblgeneratedrevenue(double dblgeneratedrevenue) {
        this.dblgeneratedrevenue = dblgeneratedrevenue;
    }

    public Salesperson() {

    }

    private int id;
    private String fname;
    private String lname;
    private String phonenumber;
    private double dblgeneratedrevenue;

    public Salesperson(int id, String fname, String lname, String phonenumber, double genrev) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.phonenumber = phonenumber;
        this.dblgeneratedrevenue= genrev;
    }

    @NonNull
    @Override
    public String toString() { return id + " " + lname; }
}
