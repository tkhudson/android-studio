package edu.exstate.tkh51.hudsonitsalespersonapp_tkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Secondscreen extends AppCompatActivity {
    double commission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondscreen);


        TextView salesFName = findViewById(R.id.txtFname);
        TextView salesLname = findViewById(R.id.txtLname);
        TextView salesPhone = findViewById(R.id.txtphonenumber);
        TextView salesGenRev = findViewById(R.id.txtgenrev);
        TextView salesComm = findViewById(R.id.txtcommission);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(Secondscreen.this);
        final Salesperson selectedSalesperson = new Salesperson(pref.getInt("KeyID", 0),
                pref.getString("KeyFName", null),
                pref.getString("KeyLName", null),
                pref.getString("KeyPhonenumber", null),
                pref.getFloat("KeyGenRev", 0));


        DecimalFormat currency = new DecimalFormat("#,###.##");
        salesFName.setText(String.valueOf(selectedSalesperson.getFname()));
        salesLname.setText(String.valueOf(selectedSalesperson.getLname()));
        salesPhone.setText (String.valueOf(selectedSalesperson.getPhonenumber()));
        salesLname.setText(String.valueOf(selectedSalesperson.getLname()));
        salesGenRev.setText(currency.format(selectedSalesperson.getDblgeneratedrevenue()));

        commission = selectedSalesperson.getDblgeneratedrevenue() * .12;

        salesComm.setText(currency.format(commission));

    }
}