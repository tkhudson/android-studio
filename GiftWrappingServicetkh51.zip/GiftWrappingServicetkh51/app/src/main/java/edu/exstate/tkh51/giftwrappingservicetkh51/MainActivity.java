package edu.exstate.tkh51.giftwrappingservicetkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    double dblLargeItemCharge = 10.50;
    double dblRegularItemCharge = 6.25;
    int intnumberentered;
    double dblTotalCharge;
    Integer number;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText numberofitem = findViewById(R.id.txtNumberOfItems);
        RadioButton large = findViewById(R.id.radLarge);
        RadioButton regular = findViewById(R.id.radRegular);
        Button findpayment = findViewById(R.id.btnFindPayment);

        findpayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (large.isChecked()){
                    if (intnumberentered > 0){
                        DecimalFormat currency = new DecimalFormat("$###,###.##");
                        dblTotalCharge = dblLargeItemCharge * intnumberentered;
                        Toast.makeText(MainActivity.this, "Total Payment: " + currency.format(dblTotalCharge), Toast.LENGTH_LONG).show();
                        startActivity(new Intent(MainActivity.this, SpecialistSelection.class));
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Invalid Input!", Toast.LENGTH_LONG).show();
                    }
                }

                try {
                    String strNumberEntered = numberofitem.getText().toString();
                    intnumberentered = Integer.parseInt(strNumberEntered);
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this, "Please enter Number of Items!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (regular.isChecked()) {
                    if (intnumberentered > 0){
                        DecimalFormat currency = new DecimalFormat("$###,###.##");
                        dblTotalCharge = dblRegularItemCharge * intnumberentered;
                        Toast.makeText(MainActivity.this, "Total Payment: " + currency.format(dblTotalCharge), Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Invalid Input!", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });
    }
}