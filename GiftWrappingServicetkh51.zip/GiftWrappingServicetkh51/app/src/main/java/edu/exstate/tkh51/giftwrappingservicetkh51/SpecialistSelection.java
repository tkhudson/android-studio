package edu.exstate.tkh51.giftwrappingservicetkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;
import java.text.DecimalFormat;

public class SpecialistSelection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specialist_selection);
        Spinner specialistselect = findViewById(R.id.spnSpecialistChoices);
        Button seeSelected = findViewById(R.id.btnSelect);
        TextView displaySpecialist = findViewById(R.id.txtDisplaySpecialist);

        seeSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txtSpecialist = specialistselect.getSelectedItem().toString();
                displaySpecialist.setText("Specialist selected: " + txtSpecialist);
            }
        });
    }
}