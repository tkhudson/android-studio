package edu.exstate.tkh51.newcarapp_tkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class msrp_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msrp_activity);

        TextView carMake = findViewById(R.id.txtMake);
        TextView carModel = findViewById(R.id.txtModel);
        TextView carMSRP = findViewById(R.id.txtMSRP);
        final EditText discountoncar = findViewById(R.id.txtdiscount);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(msrp_activity.this);
        final Car selectedCar = new Car(pref.getInt("KeyID", 0),
                pref.getString("KeyMake", null),
                pref.getString("KeyModel", null),
                pref.getString("KeyUrl", null),
                pref.getFloat("KeyMSRP", 0));

        DecimalFormat currency = new DecimalFormat("#,###.##");
        carMake.setText("Make: " + String.valueOf(selectedCar.getMake()));
        carModel.setText("Model: " + String.valueOf(selectedCar.getModel()));
        carMSRP.setText("MSRP: $" + currency.format(selectedCar.getMsrp()));

        Button totalCost = findViewById(R.id.btnCalculate);
        totalCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    int intdiscount = Integer.parseInt(discountoncar.getText().toString());
                    double totalCost = selectedCar.getMsrp() - intdiscount;
                    Toast.makeText(msrp_activity.this, "Total cost is: $" + totalCost, Toast.LENGTH_LONG).show();

                }
                catch (Exception ex){
                    Toast.makeText(msrp_activity.this, "Please enter discount on car.", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}