package edu.exstate.tkh51.newcarapp_tkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.message.BasicHeader;

public class MainActivity extends ListActivity {

    List<Car> list = new ArrayList<Car>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader("Accept", "application/json"));
        RestClient.get(MainActivity.this, "new_cars_tkh51.json", headers.toArray(new Header[headers.size()]),
                null, new JsonHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                        //super.onSuccess(statusCode, headers, response);
                        for (int i=0; i < response.length(); i++){
                            try {
                                Car bean = new Car(response.getJSONObject(i));
                                list.add(bean);
                            } catch (JSONException ex) {
                                ex.printStackTrace();
                            }
                        }
                        setListAdapter(new ArrayAdapter<Car>(MainActivity.this, R.layout.layout_cars, R.id.txtCars,list));
                    }
                });

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id){
        Car selectedCar = list.get(position);

        DecimalFormat currency = new DecimalFormat("#,###.##");
        SharedPreferences prefer = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        SharedPreferences.Editor editor = prefer.edit();
        editor.putInt("KeyID", selectedCar.getId());
        editor.putString("KeyMake", selectedCar.getMake());
        editor.putString("KeyModel", selectedCar.getModel());
        editor.putString("KeyURL", selectedCar.getUrl());
        editor.putFloat("KeyMSRP", (float) selectedCar.getMsrp());

        editor.commit();

        if(selectedCar.getMsrp() < 1) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(selectedCar.getUrl())));
            } catch (Exception ex) {

            }
        } else {
            startActivity(new Intent(MainActivity.this, msrp_activity.class));
        } 

    }
}