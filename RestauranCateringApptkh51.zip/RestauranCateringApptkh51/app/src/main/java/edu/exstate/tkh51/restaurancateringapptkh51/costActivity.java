package edu.exstate.tkh51.restaurancateringapptkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;
import java.text.DecimalFormat;

public class costActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cost);

        TextView restName = findViewById(R.id.txtRestName);
        TextView restID = findViewById(R.id.txtRestID);
        TextView restCity = findViewById(R.id.txtRestCity);
        TextView restPhone = findViewById(R.id.txtRestPhone);
        TextView restCost = findViewById(R.id.txtRestCost);
        final EditText numberofpeople = findViewById(R.id.txtnumberOfPeople);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(costActivity.this);
        final Restaurant selectedRestaurant = new Restaurant(pref.getInt("KeyID", 0),
                pref.getString("KeyName", null),
                pref.getString("KeyCity", null),
                pref.getString("KeyPhonenumber", null),
                pref.getString("KeyUrl", null),
                pref.getFloat("KeyCost", 0));

        DecimalFormat currency = new DecimalFormat("#,###.##");
        restID.setText("ID: " + String.valueOf(selectedRestaurant.getId()));
        restName.setText("Name: " + String.valueOf(selectedRestaurant.getName()));
        restCity.setText("City: " + String.valueOf(selectedRestaurant.getCity()));
        restPhone.setText("Phone: " + String.valueOf(selectedRestaurant.getPhonenumber()));
        restCost.setText("Cost per person: $" + currency.format(selectedRestaurant.getDblcostperperson()));

        Button getInfo = findViewById(R.id.btnInfo);
        getInfo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(selectedRestaurant.getUrl())));
            }
        });

        Button totalCost = findViewById(R.id.btnCalculateTotal);
        totalCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    int intNumberofpeople = Integer.parseInt(numberofpeople.getText().toString());
                    double totalCost = selectedRestaurant.getDblcostperperson() * intNumberofpeople;
                    Toast.makeText(costActivity.this, "Total cost is: $" + totalCost, Toast.LENGTH_LONG).show();

                }
                catch (Exception ex){
                    Toast.makeText(costActivity.this, "Please enter number of people.", Toast.LENGTH_LONG).show();
                }
            }
        });


    }
}