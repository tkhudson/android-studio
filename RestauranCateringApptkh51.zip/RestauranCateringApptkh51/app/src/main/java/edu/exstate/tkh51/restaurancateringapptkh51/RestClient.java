package edu.exstate.tkh51.restaurancateringapptkh51;

import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import cz.msebera.android.httpclient.Header;

public class RestClient {

    //server and database location
    private static final String BASE_URL = "https://restaurants-f08f3-default-rtdb.firebaseio.com/";
    private static AsyncHttpClient client = new AsyncHttpClient();
    //json collection
    private static String getAbsoluteUrl(String relativeUrl) {
        return BASE_URL + relativeUrl;
    }

    public static void get(Context context, String url, Header[] headers, RequestParams params,
                           AsyncHttpResponseHandler responseHandler) {
        client.get(context, getAbsoluteUrl(url), headers, params, responseHandler);
    }
}
