package edu.exstate.tkh51.restaurancateringapptkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.message.BasicHeader;

public class Listings extends ListActivity {
    //String[] strRestaurants = {"Texas Roadhouse -- San Marcos, TX",
     //                          "Saltgrass Stakehouse -- San Marcos, TX",
      //                         "54th Street -- San Marcos, TX",
       //                        "Hopdoddy Burger Bar -- San Marcos, TX",
        //                       "P. Terry's Burger Stand -- San Marcos, TX"};
    List<Restaurant> list = new ArrayList<Restaurant>();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_listings);

        List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader("Accept", "application/json"));
        RestClient.get(Listings.this, "restaurants.json", headers.toArray(new Header[headers.size()]),
                null, new JsonHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                        //super.onSuccess(statusCode, headers, response);
                        for (int i=0; i < response.length(); i++){
                            try {
                                Restaurant bean = new Restaurant(response.getJSONObject(i));
                                list.add(bean);
                            } catch (JSONException ex) {
                                ex.printStackTrace();
                            }
                        }
                        setListAdapter(new ArrayAdapter<Restaurant>(Listings.this, R.layout.layout_restaurants, R.id.txtRestaurants,list));
                    }
                });
    }
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id){
        Restaurant selectedRestaurant = list.get(position);

        DecimalFormat currency = new DecimalFormat("#,###.##");
        Toast.makeText(Listings.this, "Cost per person will be: $" + currency.format(selectedRestaurant.getDblcostperperson()),
                Toast.LENGTH_LONG).show();
        SharedPreferences prefer = PreferenceManager.getDefaultSharedPreferences(Listings.this);
        SharedPreferences.Editor editor = prefer.edit();
        editor.putInt("KeyID", selectedRestaurant.getId());
        editor.putString("KeyName", selectedRestaurant.getName());
        editor.putString("KeyCity", selectedRestaurant.getCity());
        editor.putString("KeyUrl", selectedRestaurant.getUrl());
        editor.putString("KeyPhonenumber", selectedRestaurant.getPhonenumber());
        editor.putFloat("KeyCost", (float) selectedRestaurant.getDblcostperperson());

        editor.commit();

        startActivity(new Intent(Listings.this, costActivity.class));

    }
}