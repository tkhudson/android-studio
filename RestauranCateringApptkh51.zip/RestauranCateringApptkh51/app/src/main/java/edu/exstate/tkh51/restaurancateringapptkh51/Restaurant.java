package edu.exstate.tkh51.restaurancateringapptkh51;

import androidx.annotation.NonNull;

import org.json.JSONException;
import org.json.JSONObject;

public class Restaurant {

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public double getDblcostperperson() {
        return dblcostperperson;
    }

    public void setDblcostperperson(double dblcostperperson) {
        this.dblcostperperson = dblcostperperson;
    }

    public Restaurant() {

    }

    public Restaurant(JSONObject object) {
        try {
            this.id = object.getInt("Id");
            this.name = object.getString("Name");
            this.city = object.getString("City");
            this.url = object.getString("Url");
            this.phonenumber = object.getString("Phone");
            this.dblcostperperson = object.getDouble("Cost");

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private int id;
    private String name;
    private String city;
    private String url;
    private String phonenumber;
    private double dblcostperperson;

    public Restaurant(int id, String name, String city, String phonenumber, String url, double cost) {
        this.id = id;
        this.name = name;
        this.city = city;
        this.phonenumber = phonenumber;
        this.url = url;
        this.dblcostperperson= cost;
    }

    @NonNull
    @Override
    public String toString() { return name + ":" + city; }


}
