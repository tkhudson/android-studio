package edu.exstate.tkh51.cabfarecarwash_tkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class CarWash extends AppCompatActivity {

    double dblNumberOfWashes;
    double dblCalculation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_wash);

        EditText numberOfWashes = findViewById(R.id.txtNumberofWashes);
        RadioButton exterioronly = findViewById(R.id.radExteriorOnly);
        RadioButton exteriorplus = findViewById(R.id.radExteriorPlus);
        Button calculatewash = findViewById(R.id.btnCalculateWash);
        TextView calculationresult = findViewById(R.id.txtCalculationResult);

        calculatewash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(numberOfWashes.getText().toString().equals("")){
                    Toast.makeText(CarWash.this, "Please enter number of washes.", Toast.LENGTH_LONG);
                    return;
                }

                try {
                    dblNumberOfWashes = Double.parseDouble(numberOfWashes.getText().toString());
                } catch (Exception ex){
                    Toast.makeText(CarWash.this, "Invalid Input!", Toast.LENGTH_LONG);
                    return;
                }

                if (exteriorplus.isChecked()){
                    if (dblNumberOfWashes < 10){
                        dblCalculation = 17.25;
                    }
                    else{
                        dblCalculation = 15;
                    }
                } else{
                    dblCalculation = 10.5;
                }


                DecimalFormat currency = new DecimalFormat("$###,###.##");

                calculationresult.setText("The total cost: " + currency.format(dblCalculation));
            }
        });
    }
}