package edu.exstate.tkh51.cabfarecarwash_tkh51;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;

import java.text.DecimalFormat;

public class CabFare extends AppCompatActivity {

    double dblInitialFee = 2.5;
    double dblMileageRate = 3.25;
    int intDistanceEntered;
    double dblCabFare;
    Integer number;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cab_fare);
        EditText distance = findViewById(R.id.txtDistance);
        Spinner cabpreference = findViewById(R.id.spnCabPreference);
        Button seeResults = findViewById(R.id.btnSeeResults);
        TextView results = findViewById(R.id.txtResults);

        seeResults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String strDistanceEntered = distance.getText().toString();
                    intDistanceEntered = Integer.parseInt(strDistanceEntered);
                } catch (Exception ex) {
                    Toast.makeText(CabFare.this, "Please enter distance!", Toast.LENGTH_LONG).show();
                    return;
                }
                dblCabFare = (intDistanceEntered * dblMileageRate) + dblInitialFee;

                String txtVehicle = cabpreference.getSelectedItem().toString();

                DecimalFormat currency = new DecimalFormat("$###,###.##");

                results.setText("The total cost: " + currency.format(dblCabFare) + "; your choice: " + txtVehicle + ".");

            }
        });
    }
}