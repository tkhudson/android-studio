package edu.txstate.sl20.concertticket;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    double dblCostPerTicket = 79.99; //primitive data, no methods
    //float dblCostPerTicket = 79.99f;
    int intNumberOfTickets;  //default value = 0
    double dblTotalCost; //default value = 0.0
    Integer number; //default value = null

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText numberOfTickets = findViewById(R.id.txtNumberOfTickets);
        Spinner group = findViewById(R.id.spnConcerts);
        Button findTheCost = findViewById(R.id.btnFindTheCost);
        TextView results = findViewById(R.id.txtResults);

        findTheCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //////// Event Handling
                String strNumberOfTickets = numberOfTickets.getText().toString();
                try {
                    intNumberOfTickets = Integer.parseInt(strNumberOfTickets);
                } catch (Exception ex){
                    Toast.makeText(MainActivity.this, "Please enter a number!", Toast.LENGTH_LONG).show();
                    return;
                }
                dblTotalCost = intNumberOfTickets * dblCostPerTicket;

                //Get the selected concert
                String txtConcert = group.getSelectedItem().toString();

                DecimalFormat currency = new DecimalFormat("$###,###.##");
                results.setText("The total cost: " + currency.format(dblTotalCost) + "; your choice: " + txtConcert + ".");

            }
        });



    }
}